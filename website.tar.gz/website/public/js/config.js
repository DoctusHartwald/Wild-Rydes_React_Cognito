window._config = {
    cognito: {
        userPoolId: 'us-west-2_O5JFdvjUm',
        userPoolClientId: '6k6nudo0cjga0jf83qmgplnhg4',
        region: 'us-west-2'
    },
    api: {
        invokeUrl: '' // e.g. https://rc7nyt4tql.execute-api.us-west-2.amazonaws.com/prod',
    }
};
